-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Aug 20, 2015 at 11:43 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurant_cuisine`
--
CREATE DATABASE IF NOT EXISTS `restaurant_cuisine` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `restaurant_cuisine`;

-- --------------------------------------------------------

--
-- Table structure for table `cuisines`
--

CREATE TABLE IF NOT EXISTS `cuisines` (
  `id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cuisines`
--

INSERT INTO `cuisines` (`id`, `type`) VALUES
(18, 'Mexican'),
(19, 'Italian'),
(20, 'Chinese'),
(21, 'Thai');

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE IF NOT EXISTS `restaurants` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `cuisine_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`id`, `name`, `phone`, `address`, `website`, `cuisine_id`) VALUES
(12, 'Wongs King', '(503) 788-8883', '8733 Southeast Division Street #101, Portland, OR 97266', 'http://www.wongsking.com/', 20),
(13, 'Nostrana', '(503) 234-2427', '1401 SE Morrison St, Portland, OR 97214', 'http://nostrana.com/', 19),
(14, 'Mi Mero Mole', '(971) 266-8575', '32 NW 5th Ave, Portland, OR 97209', 'http://mmmtacospdx.com/', 18),
(15, 'Rigobertos', '(503) 659-8124', '15855 SE McLoughlin Blvd, Milwaukie, OR 97267', 'http://www.rigobertotacoshop.com/', 18),
(16, 'Dragonwell Bistro', '(503) 224-0800', '735 Southwest 1st Avenue, Portland, OR 97204', 'http://dragonwellbistro.com/', 20),
(17, 'Oven and Shaker', '(503) 241-1600', '1134 NW Everett St, Portland, OR 97209', 'http://ovenandshaker.com/', 19),
(18, 'Pok Pok', '(503) 232-1387', '3226 SE Division St, Portland, OR 97202', 'http://www.pokpokpdx.com/', 21),
(19, 'Pazzo Ristorante', '(503) 228-1515', '627 SW Washington St, Portland, OR 97205', 'http://www.pazzo.com/', 19);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE IF NOT EXISTS `reviews` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL,
  `rating` int(11) DEFAULT NULL,
  `review_text` varchar(255) DEFAULT NULL,
  `restaurant_id` int(11) DEFAULT NULL,
  `review_date` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`name`, `id`, `rating`, `review_text`, `restaurant_id`, `review_date`) VALUES
('Bob', 1, 5, 'THIS IS GOOOOOOD', 10, '2015-01-01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cuisines`
--
ALTER TABLE `cuisines`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cuisines`
--
ALTER TABLE `cuisines`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `restaurants`
--
ALTER TABLE `restaurants`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
